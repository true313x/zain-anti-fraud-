# Zain IQ FraudShield
Hackathon-ready multi-agent fraud/scam detection prototype.

## Run
```bash
docker compose up --build
```
Dashboard: http://localhost:5173
API: http://localhost:8000
Swagger: http://localhost:8000/docs

This repository uses synthetic/demo data and a Mock Zain integration. Production integration requires authorized Zain APIs and security/privacy review.
