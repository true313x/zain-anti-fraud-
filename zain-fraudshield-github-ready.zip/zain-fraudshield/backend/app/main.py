import os,json
from fastapi import FastAPI,WebSocket
from fastapi.middleware.cors import CORSMiddleware
from app.schemas import TransactionRequest,AssistantRequest
from app.agents.orchestrator import FraudOrchestrator
app=FastAPI(title="Zain IQ FraudShield",version="1.0")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
o=FraudOrchestrator(os.getenv("MODEL_PATH","models/fraudshield_rf.joblib"))
S={
"normal":dict(user_id="normal",amount=35000,recipient_id="trusted",amount_vs_average=.8,message="تحويل اعتيادي"),
"scam":dict(user_id="scam",amount=750000,recipient_id="unknown",recipient_new=True,device_changed=True,transactions_5m=6,amount_5m=1500000,amount_vs_average=16.6,message="مبروك ربحت 5 مليون اضغط الرابط لتأكيد الجائزة",url="http://zain-login-security.example"),
"otp":dict(user_id="otp",amount=250000,recipient_id="unknown",recipient_new=True,device_changed=True,transactions_5m=2,amount_vs_average=5,message="أرسل رمز OTP لتأكيد حسابك فوراً",url="http://verify-account.example"),
"fake_support":dict(user_id="support",amount=400000,recipient_id="unknown",recipient_new=True,device_changed=True,transactions_5m=3,amount_vs_average=7,message="نحن من الدعم أرسل رمز التحقق فوراً",url="http://support-security.example")}
@app.get("/health")
async def health():return {"status":"healthy","mode":"hackathon"}
@app.post("/api/v1/fraud/analyze")
async def analyze(t:TransactionRequest):return await o.analyze(t)
@app.get("/api/v1/demo/scenarios")
async def scenarios():return [{"id":k} for k in S]
@app.post("/api/v1/demo/scenarios/{sid}/run")
async def run(sid:str):return await o.analyze(TransactionRequest(**S[sid]))
@app.post("/api/v1/assistant/chat")
async def chat(x:AssistantRequest):
 r=await o.analyze(x.transaction);return {"reply":r["explanation"],"decision":r["decision"],"risk_score":r["risk_score"]}
@app.websocket("/ws/fraud-events")
async def ws(s:WebSocket):
 await s.accept()
 for a in ["TRANSACTION","BEHAVIOR","SCAM","MESSAGE","LINK","ML","RISK_FUSION","DECISION"]:await s.send_text(json.dumps({"agent":a}))
 await s.close()
