class MessageAgent:
 async def analyze(self,t):
  x=(t.message or "").lower();s=[];score=0
  if any(v in x for v in ["urgent","فوراً","عاجل","immediately"]): score+=30;s.append("URGENCY_LANGUAGE")
  if any(v in x for v in ["otp","رمز","password","كلمة المرور","pin"]): score+=50;s.append("SENSITIVE_CREDENTIAL_REQUEST")
  return {"agent":"message","score":min(score,100),"signals":s}
