class BehaviorAgent:
 async def analyze(self,t):
  s=[]; score=0
  if t.amount_vs_average>=10: score+=70;s.append("EXTREME_AMOUNT_DEVIATION")
  elif t.amount_vs_average>=5: score+=45;s.append("HIGH_AMOUNT_DEVIATION")
  elif t.amount_vs_average>=3: score+=25;s.append("UNUSUAL_AMOUNT_DEVIATION")
  if t.transactions_5m>=5: score+=25;s.append("HIGH_TRANSACTION_VELOCITY")
  return {"agent":"behavior","score":min(score,100),"signals":s}
