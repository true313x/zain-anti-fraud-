from urllib.parse import urlparse
class LinkAgent:
 async def analyze(self,t):
  if not t.url:return {"agent":"link","score":0,"signals":[]}
  p=urlparse(t.url.lower());score=0;s=[]
  if p.scheme!="https":score+=30;s.append("NON_HTTPS")
  for v in ["login","verify","security","account","winner","reward","support"]:
   if v in p.netloc:score+=15;s.append("SUSPICIOUS_DOMAIN_TERM:"+v)
  return {"agent":"link","score":min(score,100),"signals":s}
