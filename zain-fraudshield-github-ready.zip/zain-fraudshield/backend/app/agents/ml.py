from pathlib import Path
import joblib,pandas as pd
FEATURES=["amount","recipient_new","device_changed","transactions_5m","amount_5m","amount_vs_average","scam_score","url_score","hour","recipient_history","device_history"]
class MLAgent:
 def __init__(self,path):self.model=joblib.load(path) if Path(path).exists() else None
 async def analyze(self,t,c):
  if not self.model:return {"agent":"ml","score":50,"signals":["MODEL_NOT_TRAINED"]}
  r=pd.DataFrame([{"amount":t.amount,"recipient_new":int(t.recipient_new),"device_changed":int(t.device_changed),"transactions_5m":t.transactions_5m,"amount_5m":t.amount_5m,"amount_vs_average":t.amount_vs_average,"scam_score":c["scam_score"],"url_score":c["url_score"],"hour":t.hour,"recipient_history":t.recipient_history,"device_history":t.device_history}])[FEATURES]
  p=float(self.model.predict_proba(r)[0][1])
  return {"agent":"ml","score":round(p*100,2),"signals":["ML_FRAUD_PROBABILITY"]}
