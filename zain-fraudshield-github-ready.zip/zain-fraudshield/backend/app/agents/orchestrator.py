import asyncio,uuid
from app.agents.transaction import TransactionAgent
from app.agents.behavior import BehaviorAgent
from app.agents.scam import ScamAgent
from app.agents.message import MessageAgent
from app.agents.link import LinkAgent
from app.agents.ml import MLAgent
from app.engine.risk import fuse,decide
from app.engine.explain import explain
class FraudOrchestrator:
 def __init__(self,path):
  self.a=[TransactionAgent(),BehaviorAgent(),ScamAgent(),MessageAgent(),LinkAgent()];self.ml=MLAgent(path)
 async def analyze(self,t):
  rs=await asyncio.gather(*[a.analyze(t) for a in self.a])
  scam=next(x["score"] for x in rs if x["agent"]=="scam");link=next(x["score"] for x in rs if x["agent"]=="link")
  rs.append(await self.ml.analyze(t,{"scam_score":scam,"url_score":link}))
  score,conf=fuse(rs);d=decide(score,conf,rs)
  return {"risk_score":score,"confidence":conf,"decision":d,"explanation":explain(d,rs),"signals":rs,"request_id":str(uuid.uuid4()),"demo":True}
