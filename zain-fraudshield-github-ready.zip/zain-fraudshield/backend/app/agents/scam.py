PATTERNS=["مبروك ربحت","اضغط الرابط","الجائزة","أكد حسابك","رمز التحقق","otp","winner","free prize","verify account","urgent"]
class ScamAgent:
 async def analyze(self,t):
  text=(t.message or "").lower()
  h=[p for p in PATTERNS if p.lower() in text]
  return {"agent":"scam","score":min(len(h)*25,100),"signals":[f"SCAM_PATTERN:{x}" for x in h]}
