class TransactionAgent:
 async def analyze(self,t):
  s=[]; score=0
  if t.amount>=500000: score+=30;s.append("HIGH_TRANSACTION_AMOUNT")
  if t.recipient_new: score+=30;s.append("NEW_RECIPIENT")
  if t.device_changed: score+=20;s.append("DEVICE_CHANGED")
  return {"agent":"transaction","score":min(score,100),"signals":s}
