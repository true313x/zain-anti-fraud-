from typing import Optional
from pydantic import BaseModel, Field
class TransactionRequest(BaseModel):
    user_id:str
    amount:float=Field(gt=0)
    currency:str="IQD"
    recipient_id:str
    recipient_new:bool=False
    device_changed:bool=False
    transactions_5m:int=1
    amount_5m:float=0
    amount_vs_average:float=1
    recipient_history:int=0
    device_history:int=1
    hour:int=Field(default=12,ge=0,le=23)
    message:Optional[str]=None
    url:Optional[str]=None
class AssistantRequest(BaseModel):
    transaction:TransactionRequest
    message:str
