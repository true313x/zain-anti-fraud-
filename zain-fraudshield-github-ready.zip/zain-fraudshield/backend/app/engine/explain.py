def explain(decision,rs):
 m={"NEW_RECIPIENT":"المستفيد جديد","HIGH_TRANSACTION_AMOUNT":"قيمة العملية مرتفعة","DEVICE_CHANGED":"تغيير في الجهاز","EXTREME_AMOUNT_DEVIATION":"المبلغ أعلى بكثير من المعتاد","HIGH_TRANSACTION_VELOCITY":"سرعة العمليات مرتفعة","URGENCY_LANGUAGE":"لغة استعجال","SENSITIVE_CREDENTIAL_REQUEST":"طلب معلومات حساسة","NON_HTTPS":"الرابط غير مشفر"}
 e=[]
 for r in rs:e += r.get("signals",[])
 e=[m.get(x.split(":")[0],x) for x in e[:6]]
 p={"BLOCK":"تم إيقاف العملية مؤقتاً بسبب عدة مؤشرات خطر.","REVIEW":"توجد مؤشرات تستحق المراجعة.","WARN":"توجد مؤشرات خطر؛ يُنصح بالتأكد قبل المتابعة.","ALLOW":"لم تظهر مؤشرات قوية على الاحتيال."}[decision]
 return p+(" "+"، ".join(e)+"." if e else "")
