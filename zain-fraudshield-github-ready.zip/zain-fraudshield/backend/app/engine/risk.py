def fuse(rs):
 w={"transaction":.15,"behavior":.2,"scam":.2,"message":.1,"link":.15,"ml":.2}
 score=sum(x["score"]*w.get(x["agent"],0) for x in rs)
 conf=min(.45+.1*sum(x["score"]>=60 for x in rs),.98)
 return round(min(score,100),2),round(conf,2)
def decide(score,conf,rs):
 if conf<.45:return "REVIEW"
 strong=sum(x["score"]>=70 for x in rs if x["agent"] in ["behavior","scam","message","link","ml"])
 if score>=85 and strong>=2:return "BLOCK"
 if score>=60:return "REVIEW"
 if score>=30:return "WARN"
 return "ALLOW"
